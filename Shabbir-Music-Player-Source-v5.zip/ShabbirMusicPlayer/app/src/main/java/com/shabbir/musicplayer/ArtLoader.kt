package com.shabbir.musicplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

object ArtLoader {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val misses = ConcurrentHashMap.newKeySet<String>()

    fun cached(key: String): Bitmap? = cache.get(key)

    suspend fun load(context: Context, track: AudioTrack, px: Int): Bitmap? {
        val key = "${track.id}:$px"
        cache.get(key)?.let { return it }
        if (misses.contains(key)) return null
        val bmp = withContext(Dispatchers.IO) { fetch(context.applicationContext, track, px) }
        if (bmp != null) cache.put(key, bmp) else misses.add(key)
        return bmp
    }

    private fun fetch(context: Context, track: AudioTrack, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return context.contentResolver.loadThumbnail(track.uri, Size(px, px), null)
            } catch (e: Exception) {
                // fall through to embedded picture
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, track.uri)
            val bytes = retriever.embeddedPicture
            if (bytes != null) decodeScaled(bytes, px) else null
        } catch (e: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun decodeScaled(bytes: ByteArray, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }
}
