package com.shabbir.musicplayer

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.exoplayer.ExoPlayer

/** Shared between the playback service and the UI (same process). */
object PlaybackHub {
    private val handler = Handler(Looper.getMainLooper())
    private var prefs: SharedPreferences? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    var player: ExoPlayer? = null

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences("fx", Context.MODE_PRIVATE)
    }

    // ---------- Sleep timer ----------
    var sleepEndsAt by mutableLongStateOf(0L)
        private set

    private val sleepRunnable = Runnable {
        player?.pause()
        sleepEndsAt = 0L
    }

    fun startSleepTimer(minutes: Int) {
        handler.removeCallbacks(sleepRunnable)
        val safeMinutes = minutes.coerceIn(1, 24 * 60)
        val delayMs = safeMinutes * 60_000L
        sleepEndsAt = System.currentTimeMillis() + delayMs
        handler.postDelayed(sleepRunnable, delayMs)
    }

    fun cancelSleepTimer() {
        handler.removeCallbacks(sleepRunnable)
        sleepEndsAt = 0L
    }

    // ---------- Equalizer + Bass ----------
    var fxAvailable by mutableStateOf(false)
        private set
    var fxEnabled by mutableStateOf(false)
        private set
    var minLevel by mutableIntStateOf(-1500)
        private set
    var maxLevel by mutableIntStateOf(1500)
        private set
    var bandFreqs by mutableStateOf<List<Int>>(emptyList())
        private set
    var presetNames by mutableStateOf<List<String>>(emptyList())
        private set
    var bassSupported by mutableStateOf(false)
        private set
    var bassStrength by mutableIntStateOf(0)
        private set
    val bandLevels = mutableStateListOf<Int>()

    fun attachEffects(sessionId: Int) {
        if (sessionId == 0) return
        releaseEffects()
        val p = prefs
        val enabled = p?.getBoolean("enabled", false) ?: false
        try {
            val eq = Equalizer(0, sessionId)
            val bands = eq.getNumberOfBands().toInt()
            val range = eq.getBandLevelRange()
            minLevel = range[0].toInt()
            maxLevel = range[1].toInt()
            bandFreqs = List(bands) { eq.getCenterFreq(it.toShort()) / 1000 }
            presetNames = List(eq.getNumberOfPresets().toInt()) { eq.getPresetName(it.toShort()) }
            val levels = List(bands) { (p?.getInt("band$it", 0) ?: 0).coerceIn(minLevel, maxLevel) }
            levels.forEachIndexed { i, l -> eq.setBandLevel(i.toShort(), l.toShort()) }
            bandLevels.clear()
            bandLevels.addAll(levels)
            eq.setEnabled(enabled)
            equalizer = eq
            fxAvailable = true
        } catch (e: Exception) {
            equalizer = null
            fxAvailable = false
        }
        try {
            val bb = BassBoost(0, sessionId)
            bassSupported = bb.getStrengthSupported()
            if (bassSupported) {
                val s = (p?.getInt("bass", 0) ?: 0).coerceIn(0, 1000)
                bb.setStrength(s.toShort())
                bassStrength = s
            }
            bb.setEnabled(enabled)
            bassBoost = bb
        } catch (e: Exception) {
            bassBoost = null
            bassSupported = false
        }
        fxEnabled = enabled
    }

    fun releaseEffects() {
        try {
            equalizer?.release()
        } catch (e: Exception) {
        }
        try {
            bassBoost?.release()
        } catch (e: Exception) {
        }
        equalizer = null
        bassBoost = null
        fxAvailable = false
        bassSupported = false
    }

    fun setFxEnabled(enabled: Boolean) {
        fxEnabled = enabled
        try {
            equalizer?.setEnabled(enabled)
        } catch (e: Exception) {
        }
        try {
            bassBoost?.setEnabled(enabled)
        } catch (e: Exception) {
        }
        prefs?.edit()?.putBoolean("enabled", enabled)?.apply()
    }

    fun setBand(index: Int, level: Int) {
        val l = level.coerceIn(minLevel, maxLevel)
        if (index in 0 until bandLevels.size) bandLevels[index] = l
        try {
            equalizer?.setBandLevel(index.toShort(), l.toShort())
        } catch (e: Exception) {
        }
        prefs?.edit()?.putInt("band$index", l)?.apply()
        if (!fxEnabled) setFxEnabled(true)
    }

    fun setBass(strength: Int) {
        val s = strength.coerceIn(0, 1000)
        bassStrength = s
        try {
            bassBoost?.setStrength(s.toShort())
        } catch (e: Exception) {
        }
        prefs?.edit()?.putInt("bass", s)?.apply()
        if (!fxEnabled) setFxEnabled(true)
    }

    fun applyPreset(index: Int) {
        val eq = equalizer ?: return
        try {
            eq.usePreset(index.toShort())
            val e = prefs?.edit()
            for (b in 0 until bandLevels.size) {
                val level = eq.getBandLevel(b.toShort()).toInt()
                bandLevels[b] = level
                e?.putInt("band$b", level)
            }
            e?.apply()
        } catch (ex: Exception) {
        }
        if (!fxEnabled) setFxEnabled(true)
    }
}
