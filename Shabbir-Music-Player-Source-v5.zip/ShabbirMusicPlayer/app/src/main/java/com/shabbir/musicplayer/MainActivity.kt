package com.shabbir.musicplayer

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

private val Background = Color(0xFF090812)
private val SurfaceDark = Color(0xFF171426)
private val Purple = Color(0xFF9B5CFF)
private val Pink = Color(0xFFE35DFF)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private var controllerState by mutableStateOf<MediaController?>(null)
    private var pendingPlayback: Pair<List<AudioTrack>, Int>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        connectController()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    secondary = Pink,
                    background = Background,
                    surface = SurfaceDark
                )
            ) {
                MusicPlayerApp(
                    onPlayTrack = { tracks, index -> playTracks(tracks, index) },
                    controller = controllerState
                )
            }
        }
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            runCatching { future.get() }.onSuccess { controller ->
                mediaController = controller
                controllerState = controller
                pendingPlayback?.let { (tracks, index) ->
                    pendingPlayback = null
                    playTracksNow(controller, tracks, index)
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun playTracks(tracks: List<AudioTrack>, index: Int) {
        val controller = mediaController
        if (controller == null) {
            pendingPlayback = tracks.toList() to index.coerceIn(0, (tracks.size - 1).coerceAtLeast(0))
            return
        }
        playTracksNow(controller, tracks, index)
    }

    private fun playTracksNow(controller: MediaController, tracks: List<AudioTrack>, index: Int) {
        if (tracks.isEmpty()) return
        val safeIndex = index.coerceIn(0, tracks.lastIndex)
        val items = tracks.map {
            MediaItem.Builder()
                .setUri(it.uri)
                .setMediaId(it.id.toString())
                .setMediaMetadata(
                    androidx.media3.common.MediaMetadata.Builder()
                        .setTitle(it.title)
                        .setArtist(it.artist)
                        .setAlbumTitle(it.album)
                        .build()
                ).build()
        }
        controller.setMediaItems(items, safeIndex, 0L)
        controller.prepare()
        controller.play()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        controllerState = null
        super.onDestroy()
    }
}

private fun AudioTrack.matches(q: String): Boolean =
    q.isBlank() || title.contains(q, true) || artist.contains(q, true) || album.contains(q, true)

@Composable
private fun MusicPlayerApp(
    onPlayTrack: (List<AudioTrack>, Int) -> Unit,
    controller: MediaController?
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val store = remember { LibraryStore(context) }

    var tracks by remember { mutableStateOf<List<AudioTrack>>(emptyList()) }
    var selectedTab by remember { mutableStateOf("Songs") }
    var search by remember { mutableStateOf("") }
    var hasPermission by remember { mutableStateOf(false) }
    var isScanning by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentId by remember { mutableStateOf<Long?>(null) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var shuffleOn by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    var favorites by remember { mutableStateOf(store.loadFavorites()) }
    var playlists by remember { mutableStateOf(store.loadPlaylists()) }
    var showPlayer by remember { mutableStateOf(false) }
    var openPlaylist by remember { mutableStateOf<String?>(null) }
    var addTarget by remember { mutableStateOf<AudioTrack?>(null) }
    var showNewPlaylist by remember { mutableStateOf(false) }
    var pendingTrack by remember { mutableStateOf<AudioTrack?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var showSleep by remember { mutableStateOf(false) }

    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    suspend fun refreshLibrary() {
        if (isScanning || !hasPermission) return
        isScanning = true
        try {
            tracks = withContext(Dispatchers.IO) {
                AudioRepository(context.applicationContext).loadTracks()
            }
        } catch (_: SecurityException) {
            hasPermission = false
            tracks = emptyList()
        } catch (_: Exception) {
            Toast.makeText(context, "Could not scan music. Please try again.", Toast.LENGTH_SHORT).show()
        } finally {
            isScanning = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (granted) scope.launch { refreshLibrary() }
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        hasPermission = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) refreshLibrary()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    DisposableEffect(lifecycleOwner, hasPermission) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && hasPermission) {
                scope.launch { refreshLibrary() }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    DisposableEffect(controller) {
        val player = controller
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentId = mediaItem?.mediaId?.toLongOrNull()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                duration = player.duration.coerceAtLeast(1L)
            }
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffleOn = shuffleModeEnabled
            }
            override fun onRepeatModeChanged(mode: Int) { repeatMode = mode }
        }
        isPlaying = player.isPlaying
        shuffleOn = player.shuffleModeEnabled
        repeatMode = player.repeatMode
        currentId = player.currentMediaItem?.mediaId?.toLongOrNull()
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(controller) {
        while (true) {
            val player = controller
            if (player != null) {
                currentPosition = player.currentPosition.coerceAtLeast(0L)
                duration = player.duration.coerceAtLeast(1L)
            }
            nowMs = System.currentTimeMillis()
            kotlinx.coroutines.delay(500)
        }
    }

    val currentTrack = remember(tracks, currentId) { tracks.firstOrNull { it.id == currentId } }
    val filtered = remember(tracks, search) { tracks.filter { it.matches(search) } }
    val favTracks = remember(tracks, favorites, search) {
        tracks.filter { it.id in favorites && it.matches(search) }
    }
    val playlistTracks = remember(tracks, playlists, openPlaylist) {
        val byId = tracks.associateBy { it.id }
        val ids = openPlaylist?.let { playlists[it] } ?: emptyList()
        ids.mapNotNull { byId[it] }
    }

    fun toggleFavorite(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        store.saveFavorites(favorites)
    }

    fun updatePlaylists(newMap: Map<String, List<Long>>) {
        playlists = newMap
        store.savePlaylists(newMap)
    }

    fun addToPlaylist(name: String, id: Long) {
        val list = playlists[name] ?: emptyList()
        if (id !in list) {
            updatePlaylists(playlists + (name to (list + id)))
            Toast.makeText(context, "Added to $name", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Already in $name", Toast.LENGTH_SHORT).show()
        }
    }

    fun togglePlay() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    val sleepLabel: String? = if (PlaybackHub.sleepEndsAt > nowMs) {
        "Sleep in ${((PlaybackHub.sleepEndsAt - nowMs) + 59_999L) / 60_000L} min"
    } else null

    BackHandler(enabled = openPlaylist != null) { openPlaylist = null }
    BackHandler(enabled = showPlayer) { showPlayer = false }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                Column {
                    if (currentTrack != null) {
                        MiniPlayer(
                            track = currentTrack,
                            playing = isPlaying,
                            position = currentPosition,
                            duration = duration,
                            onOpen = { showPlayer = true },
                            onToggle = { togglePlay() },
                            onNext = { controller?.seekToNextMediaItem() },
                            onPrevious = { controller?.seekToPreviousMediaItem() }
                        )
                    }
                    NavigationBar(containerColor = SurfaceDark, contentColor = Color.White) {
                        listOf("Songs", "Favorites", "Playlists", "Equalizer").forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = {
                                    selectedTab = tab
                                    openPlaylist = null
                                },
                                icon = {
                                    Icon(
                                        when (tab) {
                                            "Songs" -> Icons.Default.MusicNote
                                            "Favorites" -> Icons.Default.Favorite
                                            "Playlists" -> Icons.Default.LibraryMusic
                                            else -> Icons.Default.GraphicEq
                                        }, contentDescription = tab
                                    )
                                },
                                label = { Text(tab, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Pink,
                                    selectedTextColor = Pink,
                                    indicatorColor = Color(0xFF2E2347),
                                    unselectedIconColor = Color.LightGray,
                                    unselectedTextColor = Color.LightGray
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .background(Brush.verticalGradient(listOf(Color(0xFF171026), Background)))
                    .padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SHABBIR", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("MUSIC PLAYER", color = Purple, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Box(
                        Modifier.size(44.dp).background(SurfaceDark, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Headphones, null, tint = Pink) }
                }
                Spacer(Modifier.height(14.dp))

                if (selectedTab == "Songs" || selectedTab == "Favorites") {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search your music...") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true,
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Purple,
                            unfocusedBorderColor = Color(0xFF39314D),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.height(14.dp))
                }

                when (selectedTab) {
                    "Songs" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("All Songs", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Text("${tracks.size} tracks on this device", color = Color.LightGray, fontSize = 12.sp)
                            }
                            TextButton(
                                enabled = !isScanning,
                                onClick = {
                                    hasPermission = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
                                    if (hasPermission) scope.launch { refreshLibrary() } else permissionLauncher.launch(permission)
                                }
                            ) { Text(if (isScanning) "SCANNING…" else "SCAN", color = Pink) }
                        }
                        Spacer(Modifier.height(8.dp))
                        if (!hasPermission) {
                            EmptyState(
                                title = "Allow music access",
                                message = "Give audio permission to find songs stored on your phone.",
                                button = "Allow Access",
                                onClick = { permissionLauncher.launch(permission) }
                            )
                        } else if (filtered.isEmpty()) {
                            EmptyState(
                                title = if (search.isBlank()) "No music found" else "No matching songs",
                                message = "Add audio files to your phone, then scan your library.",
                                button = if (isScanning) "Scanning…" else "Scan Again",
                                onClick = { if (!isScanning) scope.launch { refreshLibrary() } }
                            )
                        } else {
                            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                                itemsIndexed(filtered, key = { _, track -> track.id }) { index, track ->
                                    SongRow(
                                        track = track,
                                        isCurrent = track.id == currentId,
                                        isFav = track.id in favorites,
                                        onClick = { onPlayTrack(filtered, index) },
                                        onFav = { toggleFavorite(track.id) },
                                        onAddToPlaylist = { addTarget = track }
                                    )
                                }
                            }
                        }
                    }

                    "Favorites" -> {
                        Text("Favorites", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("${favTracks.size} songs", color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        if (favTracks.isEmpty()) {
                            EmptyHint(
                                icon = Icons.Default.FavoriteBorder,
                                title = "No favorites yet",
                                message = "Tap the heart on any song to keep it here."
                            )
                        } else {
                            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                                itemsIndexed(favTracks, key = { _, track -> track.id }) { index, track ->
                                    SongRow(
                                        track = track,
                                        isCurrent = track.id == currentId,
                                        isFav = true,
                                        onClick = { onPlayTrack(favTracks, index) },
                                        onFav = { toggleFavorite(track.id) },
                                        onAddToPlaylist = { addTarget = track }
                                    )
                                }
                            }
                        }
                    }

                    "Playlists" -> {
                        val openName = openPlaylist
                        if (openName == null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Playlists", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                    Text("${playlists.size} playlists", color = Color.LightGray, fontSize = 12.sp)
                                }
                                Button(
                                    onClick = {
                                        pendingTrack = null
                                        showNewPlaylist = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                                ) {
                                    Icon(Icons.Default.Add, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("New")
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            if (playlists.isEmpty()) {
                                EmptyHint(
                                    icon = Icons.Default.LibraryMusic,
                                    title = "No playlists yet",
                                    message = "Press New to make your first playlist."
                                )
                            } else {
                                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                                    items(playlists.keys.toList(), key = { it }) { name ->
                                        Row(
                                            Modifier.fillMaxWidth().clickable { openPlaylist = name }.padding(vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                Modifier.size(48.dp).background(
                                                    Brush.linearGradient(listOf(Color(0xFF4A287A), Color(0xFF201A36))),
                                                    RoundedCornerShape(13.dp)
                                                ),
                                                contentAlignment = Alignment.Center
                                            ) { Icon(Icons.Default.LibraryMusic, null, tint = Pink) }
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text("${playlists[name]?.size ?: 0} songs", color = Color.LightGray, fontSize = 12.sp)
                                            }
                                            IconButton(onClick = { deleteTarget = name }) {
                                                Icon(Icons.Default.Delete, null, tint = Color.LightGray)
                                            }
                                        }
                                        HorizontalDivider(color = Color(0xFF2A2538))
                                    }
                                }
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { openPlaylist = null }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(openName, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${playlistTracks.size} songs", color = Color.LightGray, fontSize = 12.sp)
                                }
                                if (playlistTracks.isNotEmpty()) {
                                    Button(
                                        onClick = { onPlayTrack(playlistTracks, 0) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, null)
                                        Text("Play")
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            if (playlistTracks.isEmpty()) {
                                EmptyHint(
                                    icon = Icons.Default.MusicNote,
                                    title = "This playlist is empty",
                                    message = "In the Songs tab, press the three dots on a song and choose Add to playlist."
                                )
                            } else {
                                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                                    itemsIndexed(playlistTracks, key = { _, track -> track.id }) { index, track ->
                                        SongRow(
                                            track = track,
                                            isCurrent = track.id == currentId,
                                            isFav = track.id in favorites,
                                            onClick = { onPlayTrack(playlistTracks, index) },
                                            onFav = { toggleFavorite(track.id) },
                                            onRemove = {
                                                val left = (playlists[openName] ?: emptyList()).filter { it != track.id }
                                                updatePlaylists(playlists + (openName to left))
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    else -> EqualizerPage()
                }
            }
        }

        if (showPlayer && currentTrack != null) {
            NowPlayingScreen(
                track = currentTrack,
                playing = isPlaying,
                position = currentPosition,
                duration = duration,
                shuffleOn = shuffleOn,
                repeatMode = repeatMode,
                isFav = currentTrack.id in favorites,
                sleepLabel = sleepLabel,
                onClose = { showPlayer = false },
                onToggle = { togglePlay() },
                onNext = { controller?.seekToNextMediaItem() },
                onPrevious = { controller?.seekToPreviousMediaItem() },
                onSeek = { controller?.seekTo(it) },
                onShuffle = { toggleShuffle() },
                onRepeat = { cycleRepeat() },
                onFav = { toggleFavorite(currentTrack.id) },
                onSleep = { showSleep = true }
            )
        }
    }

    // ---------- Dialogs ----------
    addTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { addTarget = null },
            title = { Text("Add to playlist") },
            text = {
                if (playlists.isEmpty()) {
                    Text("No playlists yet. Create one first.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        playlists.keys.forEach { name ->
                            Text(
                                name,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    addToPlaylist(name, target.id)
                                    addTarget = null
                                }.padding(vertical = 12.dp),
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingTrack = target
                    showNewPlaylist = true
                    addTarget = null
                }) { Text("New playlist") }
            },
            dismissButton = { TextButton(onClick = { addTarget = null }) { Text("Close") } }
        )
    }

    if (showNewPlaylist) {
        var newName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = {
                showNewPlaylist = false
                pendingTrack = null
            },
            title = { Text("New playlist") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("Playlist name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim()
                    if (n.isNotEmpty()) {
                        if (n !in playlists) updatePlaylists(playlists + (n to emptyList<Long>()))
                        pendingTrack?.let { addToPlaylist(n, it.id) }
                        showNewPlaylist = false
                        pendingTrack = null
                    }
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showNewPlaylist = false
                    pendingTrack = null
                }) { Text("Cancel") }
            }
        )
    }

    deleteTarget?.let { name ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete playlist?") },
            text = { Text("\"$name\" will be deleted. Your songs stay on the phone.") },
            confirmButton = {
                TextButton(onClick = {
                    updatePlaylists(playlists - name)
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }

    if (showSleep) {
        var customText by remember { mutableStateOf("") }
        val customMinutes = customText.toIntOrNull()
        AlertDialog(
            onDismissRequest = { showSleep = false },
            title = { Text("Sleep timer") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    listOf(5, 10, 15, 30, 45, 60, 90, 120).forEach { minutes ->
                        TextButton(onClick = {
                            PlaybackHub.startSleepTimer(minutes)
                            showSleep = false
                        }) { Text("$minutes minutes") }
                    }
                    OutlinedTextField(
                        value = customText,
                        onValueChange = { customText = it.filter { c -> c.isDigit() }.take(4) },
                        singleLine = true,
                        label = { Text("Custom minutes (1-1440)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    TextButton(
                        enabled = customMinutes != null && customMinutes in 1..1440,
                        onClick = {
                            customMinutes?.let {
                                PlaybackHub.startSleepTimer(it)
                                showSleep = false
                            }
                        }
                    ) { Text("Start custom timer") }
                    if (sleepLabel != null) {
                        TextButton(onClick = {
                            PlaybackHub.cancelSleepTimer()
                            showSleep = false
                        }) { Text("Turn off timer") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSleep = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun TrackArt(track: AudioTrack?, modifier: Modifier, corner: Dp, px: Int) {
    val context = LocalContext.current
    val art by produceState<Bitmap?>(
        initialValue = track?.let { ArtLoader.cached("${it.id}:$px") },
        key1 = track?.id,
        key2 = px
    ) {
        value = if (track == null) null else ArtLoader.load(context, track, px)
    }
    Box(
        modifier.clip(RoundedCornerShape(corner)).background(
            Brush.linearGradient(listOf(Color(0xFF4A287A), Color(0xFF201A36)))
        ),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = art
        if (bitmap != null) {
            androidx.compose.foundation.Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Default.MusicNote, null, tint = Pink)
        }
    }
}

@Composable
private fun SongRow(
    track: AudioTrack,
    isCurrent: Boolean,
    isFav: Boolean,
    onClick: () -> Unit,
    onFav: () -> Unit,
    onAddToPlaylist: (() -> Unit)? = null,
    onRemove: (() -> Unit)? = null
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TrackArt(track, Modifier.size(48.dp), 13.dp, 160)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                color = if (isCurrent) Pink else Color.White,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "${track.artist} • ${formatDuration(track.durationMs)}",
                color = Color.LightGray,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onFav, modifier = Modifier.size(38.dp)) {
            Icon(
                if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                null,
                tint = if (isFav) Pink else Color.Gray
            )
        }
        Box {
            IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Default.MoreVert, null, tint = Color.LightGray)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                if (onAddToPlaylist != null) {
                    DropdownMenuItem(
                        text = { Text("Add to playlist") },
                        onClick = {
                            menuOpen = false
                            onAddToPlaylist()
                        }
                    )
                }
                if (onRemove != null) {
                    DropdownMenuItem(
                        text = { Text("Remove from playlist") },
                        onClick = {
                            menuOpen = false
                            onRemove()
                        }
                    )
                }
            }
        }
    }
    HorizontalDivider(color = Color(0xFF2A2538))
}

@Composable
private fun EmptyState(title: String, message: String, button: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(top = 50.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.LibraryMusic, null, tint = Purple, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(message, color = Color.LightGray, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text(button) }
    }
}

@Composable
private fun EmptyHint(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, message: String) {
    Column(
        Modifier.fillMaxWidth().padding(top = 50.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(4.dp))
        Text(message, color = Color.LightGray, fontSize = 13.sp)
    }
}

@Composable
private fun MiniPlayer(
    track: AudioTrack,
    playing: Boolean,
    position: Long,
    duration: Long,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit
) {
    Surface(color = Color(0xFF211832), modifier = Modifier.fillMaxWidth()) {
        Column {
            LinearProgressIndicator(
                progress = { (position.toFloat() / duration.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Pink,
                trackColor = Color(0xFF39314D)
            )
            Row(
                Modifier.clickable(onClick = onOpen).padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TrackArt(track, Modifier.size(42.dp), 10.dp, 160)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = Color.LightGray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                IconButton(onClick = onToggle) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Pink)
                }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
            }
        }
    }
}

@Composable
private fun NowPlayingScreen(
    track: AudioTrack,
    playing: Boolean,
    position: Long,
    duration: Long,
    shuffleOn: Boolean,
    repeatMode: Int,
    isFav: Boolean,
    sleepLabel: String?,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onFav: () -> Unit,
    onSleep: () -> Unit
) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val safeDuration = duration.coerceAtLeast(1L)
    val shownPosition = if (dragging) dragValue else position.coerceIn(0L, safeDuration).toFloat()

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF2A1450), Background)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
            Text(
                "NOW PLAYING",
                color = Color.LightGray,
                fontSize = 12.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(16.dp))
        TrackArt(track, Modifier.fillMaxWidth(0.85f).aspectRatio(1f), 28.dp, 720)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(track.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = Color.LightGray, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onFav) {
                Icon(
                    if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    null,
                    tint = if (isFav) Pink else Color.LightGray
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Slider(
            value = shownPosition,
            onValueChange = {
                dragging = true
                dragValue = it
            },
            onValueChangeFinished = {
                onSeek(dragValue.toLong())
                dragging = false
            },
            valueRange = 0f..safeDuration.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = Pink,
                activeTrackColor = Purple,
                inactiveTrackColor = Color(0xFF39314D)
            )
        )
        Row(Modifier.fillMaxWidth()) {
            Text(formatDuration(shownPosition.toLong()), color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(formatDuration(safeDuration), color = Color.LightGray, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onShuffle) {
                Icon(Icons.Default.Shuffle, null, tint = if (shuffleOn) Pink else Color.LightGray)
            }
            IconButton(onClick = onPrevious) {
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(36.dp))
            }
            Box(
                Modifier.size(68.dp).background(Purple, CircleShape).clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = onRepeat) {
                Icon(
                    if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    null,
                    tint = if (repeatMode == Player.REPEAT_MODE_OFF) Color.LightGray else Pink
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onSleep) {
            Icon(Icons.Default.Bedtime, null, tint = if (sleepLabel != null) Pink else Color.LightGray)
            Spacer(Modifier.width(8.dp))
            Text(sleepLabel ?: "Sleep timer", color = if (sleepLabel != null) Pink else Color.LightGray)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun EqualizerPage() {
    val hub = PlaybackHub
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Equalizer", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (!hub.fxAvailable) {
            EmptyHint(
                icon = Icons.Default.GraphicEq,
                title = "Equalizer not ready",
                message = "Play a song once, then come back here. Some phones do not support it."
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Sound effects", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = hub.fxEnabled,
                    onCheckedChange = { hub.setFxEnabled(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Purple)
                )
            }
            if (hub.presetNames.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Presets", color = Color.LightGray, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(hub.presetNames.size) { i ->
                        AssistChip(
                            onClick = { hub.applyPreset(i) },
                            label = { Text(hub.presetNames[i]) }
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            for (i in hub.bandLevels.indices) {
                val hz = hub.bandFreqs.getOrNull(i) ?: 0
                val label = if (hz >= 1000) "%.1f kHz".format(hz / 1000f) else "$hz Hz"
                val level = hub.bandLevels[i]
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.width(62.dp))
                    Slider(
                        value = level.toFloat(),
                        onValueChange = { hub.setBand(i, it.toInt()) },
                        valueRange = hub.minLevel.toFloat()..hub.maxLevel.toFloat(),
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = Pink,
                            activeTrackColor = Purple,
                            inactiveTrackColor = Color(0xFF39314D)
                        )
                    )
                    Text("${level / 100} dB", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.width(48.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Bass boost", color = Color.White, fontSize = 16.sp)
            if (hub.bassSupported) {
                Slider(
                    value = hub.bassStrength.toFloat(),
                    onValueChange = { hub.setBass(it.toInt()) },
                    valueRange = 0f..1000f,
                    colors = SliderDefaults.colors(
                        thumbColor = Pink,
                        activeTrackColor = Purple,
                        inactiveTrackColor = Color(0xFF39314D)
                    )
                )
            } else {
                Text("Not supported on this phone.", color = Color.LightGray, fontSize = 13.sp)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
