package com.shabbir.musicplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LibraryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("library", Context.MODE_PRIVATE)

    fun loadFavorites(): Set<Long> {
        val raw = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        return raw.mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun saveFavorites(ids: Set<Long>) {
        prefs.edit().putStringSet("favorites", ids.map { it.toString() }.toSet()).apply()
    }

    fun loadPlaylists(): Map<String, List<Long>> {
        val raw = prefs.getString("playlists", null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            val result = LinkedHashMap<String, List<Long>>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val name = keys.next()
                val arr = obj.getJSONArray(name)
                result[name] = List(arr.length()) { arr.getLong(it) }
            }
            result
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun savePlaylists(map: Map<String, List<Long>>) {
        val obj = JSONObject()
        for ((name, ids) in map) {
            val arr = JSONArray()
            for (id in ids) arr.put(id)
            obj.put(name, arr)
        }
        prefs.edit().putString("playlists", obj.toString()).apply()
    }
}
