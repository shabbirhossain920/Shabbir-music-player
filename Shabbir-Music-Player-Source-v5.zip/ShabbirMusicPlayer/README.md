# Shabbir Music Player

Premium offline Android music player with a black + purple interface.

## Current source version: 1.2.1

### Included
- Android 9.0 (API 28) minimum; target SDK 36
- Kotlin + Jetpack Compose UI
- Local audio library scan using Android MediaStore
- Music scanning moved off the UI thread, with scan-state feedback and permission recovery
- Search by title, artist, and album
- MP3 and other device-indexed audio playback through Media3 ExoPlayer
- Background playback service with MediaSession system controls
- Play/pause, previous/next, seek, shuffle and repeat
- Favorites and locally saved playlists
- Album artwork with in-memory cache
- Full-screen player and mini-player
- Sleep timer (5 minutes to 2 hours presets, or custom 1-1440 minutes)
- System Equalizer and Bass Boost when supported by the device
- Controller startup queue so an early tap on a song is not silently lost
- Refresh library when returning to the app
- Black + purple visual theme

### Not included yet
Online music catalog, internet radio, custom stream URL playback, lyrics, crossfade, gapless playback, folder/artist/album browsing, backup/restore and theme customization. Online and Radio are intentionally deferred as requested.

## Build in Android Studio
1. Install Android Studio and JDK 17.
2. Open this project folder.
3. Allow Gradle to sync and download dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload all project files, including `.github`.
2. Open the **Actions** tab.
3. Run **Build APK**.
4. Download the `ShabbirMusicPlayer-APK` artifact when the workflow completes successfully.

## Verification status
This source revision has received a static source review and XML/configuration inspection. It has **not** been compiled in this environment and has **not** been installed or tested on physical Android devices or emulators. Run the Gradle build and the device test matrix before publishing.
